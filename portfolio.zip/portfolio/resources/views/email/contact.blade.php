<p>Name: {{ $user->name }}</p>
<p>EMail: {{ $user->email }}</p>
<p>Message: {{ $user->message }}</p>
