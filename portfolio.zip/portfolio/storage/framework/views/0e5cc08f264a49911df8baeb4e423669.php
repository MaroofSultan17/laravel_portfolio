        <footer class="copyright" style="padding: 10px 0; text-align: center; font-size: 14px; color: #333;">
            <div class="container">
                <div class="footer">
                    <p>© 2024 All Rights Reserved by <a href="<?php echo e(env('GITHUB ')); ?>" target="_blank"
                            rel="noopener noreferrer" style="color: #fd712c;">Maroof Sultan</a> Under the
                        Supervision of<br><a style="color: #fd712c;" href="<?php echo e(env('GITHUB')); ?>" target="_blank"
                            rel="noopener noreferrer">Mr. Muhammad Jamil</a></p>
                </div>
            </div>
        </footer>
        </div>
        <script src="<?php echo e(url('../backend/vendor/global/global.min.js')); ?>"></script>
        <script src="<?php echo e(url('../backend/vendor/bootstrap-select/dist/backend/js/bootstrap-select.min.js')); ?>"></script>
        <script src="<?php echo e(url('../backend/vendor/chart.backend/js/Chart.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(url('../backend/vendor/peity/jquery.peity.min.js')); ?>"></script>
        <script src="<?php echo e(url('../backend/vendor/apexchart/apexchart.js')); ?>"></script>
        <script src="<?php echo e(url('../backend/js/dashboard/dashboard-1.js')); ?>"></script>
        <script src="<?php echo e(url('../backend/js/custom.js')); ?>"></script>
        <script src="<?php echo e(url('../backend/js/deznav-init.js')); ?>"></script>
        <script src="<?php echo e(url('../backend/js/demo.js')); ?>"></script>
        </body>

        </html>
<?php /**PATH C:\Users\Maroof Sultan\Desktop\Laravel_Portfolio\portfolio\resources\views/backend/layouts/footer.blade.php ENDPATH**/ ?>