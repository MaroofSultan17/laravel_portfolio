<p>Name:- <?php echo e($user->name); ?></p>
<p>EMail:- <?php echo e($user->email); ?></p>
<p>Message:- <?php echo e($user->message); ?></p>
<?php /**PATH C:\Users\Maroof Sultan\Desktop\Laravel_Portfolio\portfolio\resources\views/email/contact.blade.php ENDPATH**/ ?>