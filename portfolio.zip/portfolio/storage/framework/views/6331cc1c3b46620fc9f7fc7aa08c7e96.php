<?php $__env->startSection('sitetitle', 'Works'); ?>
<?php $__env->startSection('main-container'); ?>
    <div class="content-body">
        <div class="mt-3 d-md-flex justify-content-md-end">
            <a href="<?php echo e(route('works_add.show')); ?>">
                <button class="btn me-md-2 w-20 rounded" style="background: #f25521; color: white;" type="button">Add
                    Works</button>
            </a>
        </div>
        <div class="row container-fluid">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Works List</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover text-center">
                                <thead>
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">Project Name</th>
                                        <th scope="col">Project Type</th>
                                        <th scope="col">Project Link</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row" class="d-flex justify-content-center align-items-center">
                                                <?php echo e($work->workid); ?></th>
                                            <td><?php echo e($work->name); ?></td>
                                            <td><?php echo e($work->type); ?></td>
                                            <td><a href="<?php echo e($work->link); ?>" target="_blank">Click Me to preview</a></td>
                                            <td>
                                                <div class="d-flex justify-content-center">
                                                    <a href="<?php echo e(route('works_edit.show', ['id' => $work->workid])); ?>"
                                                        class="btn btn-primary btn-sm d-flex align-items-center justify-content-center m-1"
                                                        style="width: 80px; height: 50px;">
                                                        Edit
                                                    </a>
                                                    <form action="<?php echo e(route('works.destroy', ['id' => $work->workid])); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit"
                                                            class="btn btn-danger btn-sm d-flex align-items-center justify-content-center m-1"
                                                            style="width: 80px; height: 50px;">
                                                            Delete
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maroof Sultan\Desktop\Laravel_Portfolio\portfolio\resources\views/backend/works.blade.php ENDPATH**/ ?>