<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login | MAROOF</title>
    <meta charset="utf-8">
    <meta name="author" content="DexignZone">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(url('backend/images/favicon.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('backend/vendor/chartist/css/chartist.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('backend/vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('backend/css/style.css')); ?>">
</head>

<body>
    <div class="authincation d-flex flex-column flex-lg-row flex-column-fluid">
        <div class="login-aside text-center  d-flex flex-column flex-row-auto">
            <div class="d-flex flex-column-auto flex-column pt-lg-40 pt-15">
                <div class="text-center mb-4 pt-5">
                    <a href="<?php echo e(route('dashboard.show')); ?>" class="brand-logo">
                        <img class="logo-abbr" src="<?php echo e(url('backend/images/logo/logo1.png')); ?>"></img>
                    </a>
                </div>
                <h3 class="mb-2">Welcome back!</h3>
                <p>You're going to Login<br>Maroof SUltan Portfolio</p>
            </div>
        </div>
        <div
            class="container flex-row-fluid d-flex flex-column justify-content-center position-relative overflow-hidden p-7 mx-auto">
            <div class="d-flex justify-content-center h-100 align-items-center">
                <div class="authincation-content style-2">
                    <div class="row no-gutters">
                        <div class="col-xl-12 tab-content">
                            <?php if(session()->has('success') || session()->has('error')): ?>

                                <?php if(session()->has('success')): ?>
                                    <div class="alert alert-block p-4 border-left-warning text-center"
                                        style="background-color:#fd712c; opacity:1">
                                        <strong>
                                            <h5 style="color: #ffffff"><?php echo e(session('success')); ?></h5>
                                        </strong>
                                    </div>
                                <?php elseif(session()->has('error')): ?>
                                    <div class="alert alert-block p-4 border-left-warning text-center"
                                        style="background-color:red; opacity:1">
                                        <strong>
                                            <h5 style="color: #ffffff"><?php echo e(session('error')); ?></h5>
                                        </strong>
                                    </div>
                                <?php endif; ?>

                            <?php endif; ?>
                            <form id="dz_login_signup_form" class="form-validate" action="<?php echo e(route('login.valid')); ?>"
                                enctype="multipart/form-data" method="POST">
                                <?php echo csrf_field(); ?>
                                <h3 class="text-center mb-4 text-black">Signin your account</h3>
                                <div class="form-group mb-3">
                                    <label class="mb-1 form-label text-black">Email</label>
                                    <div>
                                        <input type="email" class="form-control" value="<?php echo e(old('email')); ?>"
                                            placeholder="Email" name="email">
                                        <?php if($errors->has('email')): ?>
                                            <span class="text-danger">
                                                <?php echo e($errors->first('email')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="mb-1 form-label text-black">Password</label>
                                    <div class="position-relative">
                                        <input type="password" id="dz-password" class="form-control"
                                            value="<?php echo e(old('password')); ?>" placeholder="Password" name="password">
                                        <?php if($errors->has('password')): ?>
                                            <span class="text-danger">
                                                <?php echo e($errors->first('password')); ?>

                                            </span>
                                        <?php endif; ?>
                                        <span class="show-pass eye">
                                            <i class="fa fa-eye-slash"></i>
                                            <i class="fa fa-eye"></i>
                                        </span>
                                    </div>
                                </div>
                                <div class="text-center mt-4">
                                    <button type="submit" class="btn btn-primary btn-block">Sign In</button>
                                </div>
                            </form>
                            <div class="new-account mt-3">
                                <p>Don't have an account? <a class="text-primary"
                                        href="<?php echo e(route('signup.show')); ?>">Sign
                                        up</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo e(url('backend/vendor/global/global.min.js')); ?>"></script>
    <script src="<?php echo e(url('backend/vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
    <script src="<?php echo e(url('backend/js/custom.min.js')); ?>"></script>
    <script src="<?php echo e(url('backend/vendor/jquery-validation/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(url('backend/js/login-form.js')); ?>"></script>
    <script src="<?php echo e(url('backend/js/deznav-init.js')); ?>"></script>
    <script src="<?php echo e(url('backend/js/demo.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\Users\Maroof Sultan\Desktop\Laravel_Portfolio\portfolio\resources\views/backend/login.blade.php ENDPATH**/ ?>