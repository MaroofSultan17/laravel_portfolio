<?php $__env->startSection('sitetitle', 'Works-Edit'); ?>
<?php $__env->startSection('main-container'); ?>
    <div class="content-body">
        <div class="container-fluid">
            <div class="d-grid gap-2 d-md-flex justify-content-md-start mb-3">
                <a href="<?php echo e(route('works.show')); ?>">
                    <button class="btn me-md-2 w-20 h-100 rounded" style="background: #f25521; color: white;"
                        type="button">Show Works</button>
                </a>
            </div>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-block p-4 border-left-warning text-center"
                    style="background-color:#f25521; opacity:1">
                    <strong>
                        <h1 style="color:#ffffff"><?php echo e($message); ?></h1>
                    </strong>
                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('works.update', ['id' => $works->workid])); ?>" method="POST"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="name" name="name" placeholder="Project Name"
                        value="<?php echo e($works->name); ?>">
                    <label for="name">Project Name</label>
                    <?php if($errors->has('name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="type" name="type" placeholder="Website/App/etc"
                        value="<?php echo e($works->type); ?>">
                    <label for="type">Project Type</label>
                    <?php if($errors->has('type')): ?>
                        <span class="text-danger"><?php echo e($errors->first('type')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="client" placeholder="Client" name="client"
                        value="<?php echo e($works->client); ?>">
                    <label for="client">Client Name</label>
                    <?php if($errors->has('client')): ?>
                        <span class="text-danger"><?php echo e($errors->first('client')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="languages" placeholder="languages" name="languages"
                        value="<?php echo e($works->languages); ?>">
                    <label for="languages">Languages Used</label>
                    <?php if($errors->has('languages')): ?>
                        <span class="text-danger"><?php echo e($errors->first('languages')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="link" placeholder="link" name="link"
                        value="<?php echo e($works->link); ?>">
                    <label for="link">Project Preview Link</label>
                    <?php if($errors->has('link')): ?>
                        <span class="text-danger"><?php echo e($errors->first('link')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label>Project Image</label>
                    <div class="input-group mt-2">
                        <input type="file" class="form-control file-upload-browse" id="image" name="image"
                            accept=".png,.jpeg,.jpg">
                        <?php if($errors->has('image')): ?>
                            <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                        <?php endif; ?>
                    </div>
                    <?php if($works->image): ?>
                        <div class="mt-2">
                            <img src="<?php echo e(url($works->image)); ?>" alt="Project Image" width="200">
                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-floating mb-3">
                    <textarea class="form-control" id="details" rows="5" placeholder="Project Details" name="details"><?php echo e($works->details); ?></textarea>
                    <label for="details">Project Details</label>
                    <?php if($errors->has('details')): ?>
                        <span class="text-danger"><?php echo e($errors->first('details')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="d-md-flex justify-content-md-end">
                    <button type="submit" class="btn btn-success w-20 mb-3  rounded"
                        style="font-size: 18px;">Submit</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maroof Sultan\Desktop\Laravel_Portfolio\portfolio\resources\views/backend/works-edit.blade.php ENDPATH**/ ?>