<?php $__env->startSection('sitetitle', 'Contact-us'); ?>
<?php $__env->startSection('main-container'); ?>
    <div class="col-xxl-8 col-xl-9">
        <div class="bostami-page-content-wrap">
            <div class="section-wrapper pl-60 pr-60 pt-60">
                <div class="bostami-page-title-wrap mb-15">
                    <h2 class="page-title">contact</h2>
                </div>
            </div>
            <div class="section-wrapper pr-60 pl-60 mb-60">
                <div class="contact-area bg-light-white-2">
                    <h5 class="contact-title">I'm always open to discussing produuct</h5>
                    <h5 class="contact-title-b">Feel Free to contact.</h5>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-block p-4 border-left-warning" style="background-color:#1b74e4; opacity:1">
                            <strong>
                                <h4 style="color:#ffffff"><?php echo e($message); ?></h4>
                            </strong>
                        </div>
                    <?php endif; ?>
                    <form class="contact-form" method="POST" action="<?php echo e(route('contact.submit')); ?>"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-input-item mb-60">
                            <label class="input-lebel name">Name *</label>
                            <input name="name" class="input-box name" type="text">
                            <?php if($errors->has('name')): ?>
                                <span class="text-danger">
                                    <?php echo e($errors->first('name')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-input-item mb-60">
                            <label class="input-lebel gmail">Email *</label>
                            <input name="email" class="input-box gmail" type="Email">
                            <?php if($errors->has('email')): ?>
                                <span class="text-danger">
                                    <?php echo e($errors->first('email')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-input-item mb-40">
                            <label class="input-lebel message">Message *</label>
                            <textarea name="message" class="input-box message" cols="30" rows="10"></textarea>
                            <?php if($errors->has('message')): ?>
                                <span class="text-danger">
                                    <?php echo e($errors->first('message')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-btn-wrap">
                            <button type="submit" class="form-btn" name="submit">submit</button>
                        </div>
                    </form>
                </div>
            </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maroof Sultan\Desktop\Laravel_Portfolio\portfolio\resources\views\frontend\contact.blade.php ENDPATH**/ ?>