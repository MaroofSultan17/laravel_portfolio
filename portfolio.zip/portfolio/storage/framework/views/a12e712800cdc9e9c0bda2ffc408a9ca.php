<?php $__env->startSection('sitetitle', 'Dasboard'); ?>
<?php $__env->startSection('main-container'); ?>
    <div class="content-body">
        <div class="mt-4 d-md-flex justify-content-md-center">
        </div>
        <div class="row container-fluid">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Peoples contact us list</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover text-center">
                                <thead>
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Message</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $contactus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ContactsData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row" class="d-flex justify-content-center align-items-center">
                                                <?php echo e($ContactsData->id); ?></th>
                                            <td><?php echo e($ContactsData->name); ?></td>
                                            <td><?php echo e($ContactsData->email); ?></td>
                                            <td><?php echo e($ContactsData->message); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maroof Sultan\Desktop\Laravel_Portfolio\portfolio\resources\views\backend\index.blade.php ENDPATH**/ ?>