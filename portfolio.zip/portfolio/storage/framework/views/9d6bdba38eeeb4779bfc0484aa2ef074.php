<?php $__env->startSection('sitetitle', 'Profile'); ?>
<?php $__env->startSection('main-container'); ?>
    <div class="content-body">
        <div class="container-fluid">
            <div class="d-grid gap-2 d-md-flex justify-content-md-start mb-3">
                <a href="<?php echo e(route('profile.show')); ?>">
                    <button class="btn me-md-2 w-20 h-100 rounded" style="background: #f25521; color: white;"
                        type="button">Show Profile</button>
                </a>
            </div>
            <form action="<?php echo e(route('profile_edit.edit')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="name" name="name" placeholder="Full Name"
                        value="<?php echo e($profiledata->name); ?>">
                    <label for="name">Full Name</label>
                    <?php if($errors->has('name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="type" name="skill" placeholder="Laravel/WEB"
                        value="<?php echo e($profiledata->skill); ?>">
                    <label for="skill">Skill</label>
                    <?php if($errors->has('skill')): ?>
                        <span class="text-danger"><?php echo e($errors->first('skill')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="facebook" placeholder="facebook" name="facebook"
                        value="<?php echo e($profiledata->facebook); ?>">
                    <label for="facebook">Facebook Link</label>
                    <?php if($errors->has('facebook')): ?>
                        <span class="text-danger"><?php echo e($errors->first('facebook')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="github" placeholder="github" name="github"
                        value="<?php echo e($profiledata->github); ?>">
                    <label for="github">Github Link</label>
                    <?php if($errors->has('github')): ?>
                        <span class="text-danger"><?php echo e($errors->first('github')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="instagram" placeholder="instagram" name="instagram"
                        value="<?php echo e($profiledata->instagram); ?>">
                    <label for="instagram">Instagram Link</label>
                    <?php if($errors->has('instagram')): ?>
                        <span class="text-danger"><?php echo e($errors->first('instagram')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="linkedin" placeholder="linkedin" name="linkedin"
                        value="<?php echo e($profiledata->linkedin); ?>">
                    <label for="linkedin">Linkedin Link</label>
                    <?php if($errors->has('linkedin')): ?>
                        <span class="text-danger"><?php echo e($errors->first('linkedin')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="phoneno" placeholder="phoneno" name="phoneno"
                        value="<?php echo e($profiledata->phoneno); ?>">
                    <label for="phoneno">Phone Number</label>
                    <?php if($errors->has('phoneno')): ?>
                        <span class="text-danger"><?php echo e($errors->first('phoneno')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-floating mb-3">
                    <input type="email" class="form-control" id="email" placeholder="email" name="email"
                        value="<?php echo e($profiledata->email); ?>">
                    <label for="email">Email</label>
                    <?php if($errors->has('email')): ?>
                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="address" placeholder="address" name="address"
                        value="<?php echo e($profiledata->address); ?>">
                    <label for="address">Address</label>
                    <?php if($errors->has('address')): ?>
                        <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label>Upload Resume</label>
                    <div class="input-group mt-2">
                        <input type="file" class="form-control  file-upload-browse" id="resume" name="resume"
                            accept=".pdf,.txt,.doc,.docx" value="<?php echo e($profiledata->resume); ?>">
                        <?php if($errors->has('resume')): ?>
                            <span class="text-danger"><?php echo e($errors->first('resume')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group mb-3">
                    <label>Upload Image</label>
                    <div class="input-group mt-2">
                        <input type="file" class="form-control  file-upload-browse" id="image" name="image"
                            accept=".png,.jpg,,.jpeg" value="<?php echo e($profiledata->image); ?>">
                        <?php if($errors->has('image')): ?>
                            <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="d-md-flex justify-content-md-end">
                    <button type="submit" class="btn btn-success w-20 mb-3  rounded"
                        style="font-size: 18px;">Submit</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maroof Sultan\Desktop\Laravel_Portfolio\portfolio\resources\views\backend\profile-edit.blade.php ENDPATH**/ ?>